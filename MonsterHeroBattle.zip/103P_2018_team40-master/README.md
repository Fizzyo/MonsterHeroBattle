# 103P_2018_team40

This UCL team 40's (Fizzyo team 6) repository for our app project - contributing to the Fizzyo Game Project. 
It contains the source code for our game - Hero's Battle which we hope can be used to improve the physiotherapy for kids with cystic fibrosis.
We have used the Fizzyo library and unity package in order to interface with the breathing device. 
